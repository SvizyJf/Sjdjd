---
name: Modules bug report
about: Report a bug related to my modules
title: ""
labels: bug, module
assignees: ""
---

- [x] This bug is related to **module from official [repository](https://mods.hikariatama.ru)**.

---

**Module, related to problem** [E.g. HikariChat]:

**Short description of the bug**:

**Steps to reproduce**:

**Any additional information**:
